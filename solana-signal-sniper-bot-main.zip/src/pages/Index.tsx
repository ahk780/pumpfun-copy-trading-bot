
import React from 'react';
import { TradingDashboard } from '@/components/TradingDashboard';

const Index = () => {
  return <TradingDashboard />;
};

export default Index;
